angular.module('crudApp')
.controller('DeleteCtrl', ['$scope','$http', function ($scope,$http) {
	$scope.title = 'Delete Record';
	$http.get("app/get_data").success(function(result){
                $scope.students = result;
            });
}]);