<form name="add_student_data" class="form-horizontal" roll="form" style="margin-left:20em;margin-top:2em" >
	<div class="form-group">
        <label for="first_name" class="col-lg-2 control-label">Roll No</label>
        <div class="col-lg-4">
           <input style="border-radius:0px;" type="text" class="form-control" id="rollno" name="rollno" ng-model="roll_no" readonly>
        </div>
    </div>
	<div class="form-group">
        <label for="first_name" class="col-lg-2 control-label">Fisrst Name</label>
        <div class="col-lg-4">
           <input style="border-radius:0px;" type="text" class="form-control" id="firstname" name="firstname" ng-model="firstname" required>
        </div>
    </div>
	<div class="form-group">
		<label for="middle_name" class="col-lg-2 control-label">Second Name</label>		
        <div class="col-lg-4">									
            <input style="border-radius:0px;" type="text" class="form-control" id="middlename" name="middlename" ng-model="middlename"  required >
        </div>	
    </div>	
	<div class="form-group">
		<label for="last_name" class="col-lg-2 control-label">Last Name</label>
        <div class="col-lg-4">			
            <input style="border-radius:0px;" type="text" class="form-control" id="lastname" name="lastname" ng-model="lastname"  required >
        </div>
    </div>
	<div class="form-group">
		<label for="last_name" class="col-lg-2 control-label">Contact No</label>
        <div class="col-lg-4">			
            <input style="border-radius:0px;" type="text" class="form-control" id="contactno" name="contactno" ng-model="contactno"  required >
        </div>
    </div>
	
	<div class="form-group">
		<label for="last_name" class="col-lg-2 control-label">Email</label>
        <div class="col-lg-4">			
            <input style="border-radius:0px;" type="email" class="form-control" id="email" name="email" ng-model="email" required >
        </div>
    </div>
	<p style="color:{{message_color}};">{{message}}</p> <br />
	<div class="form-group">
        <div class="col-lg-2 col-lg-offset-4" >
            <input style="border-radius:0px;" type="submit" ng-click="updateuserData(roll_no,firstname,middlename,lastname,contactno,email)" class="btn btn-primary"  value="Update">	
        </div>
    </div>
</form>