<div class="panel panel-default"> 
	<div class="panel-heading"> 
	<h2><center>{{title}}</center></h2>
	</div> 
	<div class="panel-body"> 
		<table class="table table-striped">
			<thead>
				<th>Roll No</th>
				<th>First Name</th>
				<th>Middle Name</th>
				<th>Last Name</th>
				<th>Contact No</th>
				<th>Email</th>
			</thead>
			<tbody>
			<tr ng-repeat="student in students">
				<td>{{ student.roll_no }}	</td>
				<td>{{ student.firstname }}	</td>
				<td>{{ student.middlename }}</td>
				<td>{{ student.lastname }}	</td>
				<td>{{ student.contactno }}	</td>
				<td>{{ student.email }}		</td>
			</tr>
			</tbody>
		</table>
	</div>
<div class="panel-footer" style="padding-top:30px;padding-bottom:30px;" >
	<p style="color:{{message_color}};">{{message}}</p> <br />
</div>
</div> 