<?php

class Form extends CI_Controller {

				

        public function index()
        {
				//$this->output->enable_profiler(FALSE);
				$this->benchmark->mark('my_mark_start');
			
                $this->load->helper(array('form', 'url'));
				
                $this->load->library(array('form_validation','Calendar','javascript','javascript/jquery'));
				$this->form_validation->set_error_delimiters('<div class="error" style="color:red;">', '</div>');
					
				
					
				$atts = array(
				'width'       => 800,
				'height'      => 600,
				'scrollbars'  => 'yes',
				'status'      => 'yes',
				'resizable'   => 'yes',
				'screenx'     => 0,
				'screeny'     => 0,
				'window_name' => '_blank'
		);

				$data['link']= anchor_popup('form', 'Click Me!', $atts);	
					
					
					
                if ($this->form_validation->run('signup') == FALSE)
                {
                        $this->load->view('myform');
                }
                else
					
                {

					
                        $this->load->view('formsuccess',$data);
                }
				
				

				
					if ($this->db->table_exists('megha'))
					{
						echo "Your table is exist";
					}
					else
					{
						echo 'Your Tbale is not exist';
					}
				
				
				
				
				
				$this->benchmark->mark('my_mark_end');
							
        }
		public function username_check($str)
        {
                if ($str == 'test')
                {
                        $this->form_validation->set_message('username_check', 'The {field} field can not be the word "test"');
                        return FALSE;
                }
                else
                {
                        return TRUE;
                }
        }
		
}
?>