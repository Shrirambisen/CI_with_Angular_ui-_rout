<?php
class Test Extends CI_Controller {
	
	function index(){
		$this->load->view('test');

	}
	function testcopy(){
		$this->load->view('testcopy');

	}
}

?>