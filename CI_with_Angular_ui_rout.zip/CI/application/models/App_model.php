<?php
Class App_model extends CI_Model{
	
	public function __construct()
        {
			parent::__construct();
            $this->load->database();
        }	
		
	public function insert_data($userdata){
			$data=array
				(
					'firstname'	=> $userdata->firstname,
					'middlename'=> $userdata->middlename,
					'lastname'	=> $userdata->lastname,
					'contactno'	=> $userdata->contactno,
					'email'		=> $userdata->email
				);
			return $this->db->insert('stud', $data);
	}
	public function update_data($userdata){
		$data=array
				(
					'firstname'	=> $userdata->firstname,
					'middlename'=> $userdata->middlename,
					'lastname'	=> $userdata->lastname,
					'contactno'	=> $userdata->contactno,
					'email'		=> $userdata->email
				);
				$this->db->where("roll_no",$userdata->roll_no);
		return  $this->db->update("stud",$data);
	}
	public function delete_data($roll_no){
		$this->db->delete("stud","roll_no=$roll_no");
	}
	
	public function get_std_record()
	{
		$query=$this->db->get('stud');
		return $query->result_array();
		
	}
	//public function get_record($rollno)
	//{
	//	$query=$this->db->get_where('stud',array('roll_no'=>$rollno));
	//	return $query->result_array();
	//}
	
	
	public function db_close(){
		$this->db->close();
	}
}

?>