angular.module('crudApp')
.controller('AddCtrl', ['$scope', function ($scope) {
	$scope.title = 'Add Record';
}]);