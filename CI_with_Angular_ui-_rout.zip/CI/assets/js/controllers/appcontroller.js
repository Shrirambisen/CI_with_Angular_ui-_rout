var myApp = angular.module('myApp', ['ngRoute']);

myApp.factory('dataservice', function($http) {
	var students;
	$http.get("app/get_data").success(function(result){
               students = result;
            });
	return {
		getStudents: function() {
			 return students;
			}
	}
	
});

myApp.controller('HomeCtrl', ['$scope','$http','dataservice', function ($scope,$http,dataservice) {
	$scope.title = 'View Record' ;
	$scope.students = dataservice.getStudents();
	
}]);
myApp.controller('ViewCtrl', ['$scope','$http','dataservice', function ($scope,$http,dataservice) {
	$scope.title = 'View Record' ;
	$scope.students = dataservice.getStudents();
	
}]);
myApp.controller('UpdateCtrl', ['$scope','$http','dataservice', function ($scope,$http,dataservice) {
	$scope.title = 'Update Record';
	$scope.students = dataservice.getStudents();
	
}]);
myApp.controller('DeleteCtrl', ['$scope','$http','dataservice', function ($scope,$http,dataservice) {
	$scope.title = 'Delete Record';
	$scope.students = dataservice.getStudents();
}]);
myApp.controller('AddCtrl', ['$scope','$http', function ($scope,$http) {
	$scope.title = 'Add Record';
}]);