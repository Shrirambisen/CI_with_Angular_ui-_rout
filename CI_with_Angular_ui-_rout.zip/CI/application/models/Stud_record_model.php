<?php
Class Stud_Record_Model extends CI_Model{
	
	public function __construct()
        {
                $this->load->database();
        }	
	
	public function index(){
		$query=$this->db->get("stud");
		$data['records']=$query->result_array();
	}
			
	public function insert_data(){
		
			$data=array
				(
					'firstname'	=> $this->input->post('firstname'),
					'middlename'=> $this->input->post('middlename'),
					'lastname'	=> $this->input->post('lastname'),
					'contactno'	=> $this->input->post('contactno'),
					'email'		=> $this->input->post('email')
					
				);
			
			return $this->db->insert('stud', $data);
		
	}
	public function update_data($roll_no){
		
		$data=array
				(
					'firstname'	=> $this->input->post('firstname'),
					'middlename'=> $this->input->post('middlename'),
					'lastname'	=> $this->input->post('lastname'),
					'contactno'	=> $this->input->post('contactno'),
					'email'		=> $this->input->post('email')
				);
		
		$this->db->set($data);
		$this->db->where("roll_no",$roll_no);
		$this->db->update("stud");
	}
	public function delete_data($rollno){
		$this->db->delete("stud","roll_no=$rollno");
	}
	
	public function get_std_record()
	{
		
		$query=$this->db->get('stud');
		return $query->result_array();
		
	}
	public function get_record($rollno)
	{
		
		$query=$this->db->get_where('stud',array('roll_no'=>$rollno));
		return $query->result_array();
		
	}
	
	
	public function db_close(){
		$this->db->close();
	}
}

?>