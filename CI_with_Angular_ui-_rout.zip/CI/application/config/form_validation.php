<?php
$config = array(	
	'signup'=>array(
				array(
					 'field' => 'username',
					 'label' => 'Username',
					 'rules' => 'trim|required|min_length[5]|max_length[12]|callback_username_check',
					 'errors'=>array(
									'required'  => 'You have not provided %s.',
									'is_unique'  => 'This %s already exists.'
									)
					),
					array(
						'field' => 'password',
						'label' => 'Password',
						'rules' => 'trim|required|min_length[7]|max_length[12]',
						'errors' => array(
											'required' => 'You must provide a %s.',
										 ),
					),
					array(
							'field' => 'passconf',
							'label' => 'Password Confirmation',
							'rules' => 'trim|required|matches[password]'
					),
					array(
							'field' => 'email',
							'label' => 'Email',
							'rules' => 'trim|required|valid_email'
					)
			)
		);
		
		
?>







