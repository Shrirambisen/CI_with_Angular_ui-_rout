<?php
class Stud_rec extends CI_Controller{
	
	public function __construct(){
		
		parent::__construct();
		
	}
	
	public function index()
	{
		$data['stud'] = $this->stud_record_model->get_std_record();
		
		$this->load->view('std_rec/index',$data);
		
		
	}
	public function view_records()
	{
		$data['stud'] = $this->stud_record_model->get_std_record();
		$data['title'] = 'View Records';
		$this->load->view('std_rec/header',$data);
		$this->load->view('std_rec/view_record');
		$this->load->view('std_rec/footer');	
	}
	public function add_record()
	{
		$data['flag'] = 0;
		$data['title'] = 'Add Student Record';
		$this->load->view('std_rec/header',$data);
		$this->load->view('std_rec/add_record',$data);
		$this->load->view('std_rec/footer');
		
	}
	public function update_records()
	{
		$data['stud'] = $this->stud_record_model->get_std_record();
		$data['title'] = 'Update Records';
		$this->load->view('std_rec/header',$data);
		$this->load->view('std_rec/update_data');
		$this->load->view('std_rec/footer');	
	}

	public function delete_records()
	{
		$data['stud'] = $this->stud_record_model->get_std_record();
		$data['title'] = 'Delete Records';
		$this->load->view('std_rec/header',$data);
		$this->load->view('std_rec/delete_records');
		$this->load->view('std_rec/footer');
	}	
	
	public function insert_record()
	{
		$data['title'] = 'Add Student Record';
		
		$this->form_validation->set_rules('firstname',"First name", "alpha");
		$this->form_validation->set_rules('middlename',"Middle name", "alpha");
		$this->form_validation->set_rules('lastname',"Last name", "alpha");
		$this->form_validation->set_rules('contactno',"Contact Number", "numeric");
		$this->form_validation->set_rules('email',"Email", "valid_email");
		 
		if($this->form_validation->run()===FALSE)
		{
			$data['flag'] = 0;
			$this->load->view('std_rec/header',$data);
			$this->load->view('std_rec/add_record',$data);
			$this->load->view('std_rec/footer');
		}
		else
		{
			$this->stud_record_model->insert_data();
			$data['flag'] = 1;
			$this->session->set_flashdata('insert_success', 'The record is Added!');
			$this->load->view('std_rec/header',$data);
			$this->load->view('std_rec/add_record',$data);
			$this->load->view('std_rec/footer');
		}	
	}
	
	
	public function edit_record()
	{
		$roll_no= $this->uri->segment('3');
		$data['stud'] = $this->stud_record_model->get_record($roll_no);
		$data['title'] = 'Edit Record';
		$this->load->view('std_rec/header',$data);
		$this->load->view('std_rec/edit_record');
		$this->load->view('std_rec/footer');
	}
		
	public function update_record(){
		$roll_no=$this->input->post('rollno');
		$this->stud_record_model->update_data($roll_no);
		$this->session->set_flashdata('update_success', 'The record is Updated!');
		$data['stud'] = $this->stud_record_model->get_std_record();
		$data['title'] = 'Update Records';
		$this->load->view('std_rec/header',$data);
		$this->load->view('std_rec/update_data');
		$this->load->view('std_rec/footer');	
	}
	public function delete_record(){
		$roll_no= $this->uri->segment('3');
		$this->stud_record_model->delete_data($roll_no);
		$this->session->set_flashdata('delete_success', 'The record is deleted!');
		$data['stud'] = $this->stud_record_model->get_std_record();
		$data['title'] = 'Delete Records';
		$this->load->view('std_rec/header',$data);
		$this->load->view('std_rec/delete_records');
		$this->load->view('std_rec/footer');
	}

}

?>