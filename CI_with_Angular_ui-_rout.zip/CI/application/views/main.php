<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head> 
		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       
        <title>CodeIgniter Tutorial</title>
		
		<link href="<?php echo base_url("assets/bootstrap.min.css"); ?>" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.js"></script>
	
		<script src="//cdnjs.cloudflare.com/ajax/libs/angular-ui-router/0.2.8/angular-ui-router.min.js"></script>
		<script src="<?php echo base_url() ?>assets/js/app.js"></script>
		</head>

<body>
<div class="container">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Student Records</a>
    </div>
    <ul class="nav navbar-nav" id="mainmenu">
	  <li><a ui-sref="home">Home</a></li>
	  <li><a ui-sref="view">View Records</a></li>
      <li><a ui-sref="add">Add Records</a></li>
      <li><a ui-sref="update">Update Records</a></li>
      <li><a ui-sref="delete">Delete Records</a></li>
    </ul>
  </div>
</nav>
<!--YOUR CONTENT WILL BE INJECTED HERE-->

<div class="panel panel-default"> 
	<div class="panel-heading"> 

	</div> 
<div class="panel-body"> 
<ui-view> </ui-view>


</div>

</div>

</body>
</html>