<h2><center>{{title}}</center></h2>
<table class="table table-striped">
<tr>

<th>Roll No</th>
<th>First Name</th>
<th>Middle Name</th>
<th>Last Name</th>
<th>Contact No</th>
<th>Email</th>
<th>Delete</th>
</tr>

<tr ng-repeat="student in students">

<td>{{ student.roll_no }}	</td>
<td>{{ student.firstname }}	</td>
<td>{{ student.middlename }}</td>
<td>{{ student.lastname }}	</td>
<td>{{ student.contactno }}	</td>
<td>{{ student.email }}		</td>
<td ><button  class="btn btn-info" ng-click="deleteData(student.roll_no)">Delete</button></td>
</tr>

</table>
<p style="color:{{message_color}};">{{message}}</p> <br />