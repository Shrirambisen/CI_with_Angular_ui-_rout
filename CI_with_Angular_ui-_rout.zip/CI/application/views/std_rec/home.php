
<table class="table table-striped">
<tr>

<th>Roll No</th>
<th>First Name</th>
<th>Middle Name</th>
<th>Last Name</th>
<th>Contact No</th>
<th>Email</th>
</tr>
<tr ng-repeat="student in students">
<td>{{ student.roll_no }}</td>
<td>{{ student.firstname }}</td>
<td>{{ student.middlename }}</td>
<td>{{ student.lastname }}</td>
<td>{{ student.contactno }}</td>
<td>{{ student.email }}</td>
</tr>
</table>
