<div ng-include src="'app/edit'" ng-controller="UpdateCtrl"   ng-show="editform" > </div>

<h2><center>{{title}}</center></h2>
<p style="color:{{message_color}};">{{message}}</p> <br />
<table class="table table-striped">
<tr>

<th>Roll No</th>
<th>First Name</th>
<th>Middle Name</th>
<th>Last Name</th>
<th>Contact No</th>
<th>Email</th>
<th>Update</th>
</tr>

<tr ng-repeat="student in students">

<td>{{ student.roll_no }}	</td>
<td>{{ student.firstname }}	</td>
<td>{{ student.middlename }}</td>
<td>{{ student.lastname }}	</td>
<td>{{ student.contactno }}	</td>
<td>{{ student.email }}		</td>
<td ><button  class="btn btn-info" ng-click="updateData(student.roll_no, student.firstname, student.middlename,student.lastname,student.contactno,student.email)">Update</button></td>
</tr>
</table>

