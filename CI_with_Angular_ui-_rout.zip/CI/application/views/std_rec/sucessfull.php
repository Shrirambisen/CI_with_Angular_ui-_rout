<?php 
echo "Record added/update/deleteed Sucessfully!";
?>